
SET SERVEROUTPUT ON;
SET VERIFY OFF;

CREATE OR REPLACE PACKAGE mypack2 AS

	FUNCTION search2(m IN token1.tokenname%TYPE)
	RETURN NUMBER;
END mypack2;
/

CREATE OR REPLACE PACKAGE BODY mypack2 AS

function search2(m IN token1.tokenname%TYPE)
return number
is

l NUMBER;
c token1.tokenname%TYPE;
B alphabet1.tokenname%TYPE;
n NUMBER;
s NUMBER :=0;
itr NUMBER :=1;



BEGIN
	l:= length(m);
	IF (m like '1%' OR m like '2%' OR m like '3%' OR m like '4%' OR m like '5%'
		OR m like '6%' OR m like '7%' OR m like '8%' OR m like '9%' OR m like '0%' OR m like '.%')THEN
		
		IF (m like '.%')THEN
			s:= 2;
		ELSE
			s:=1;
		END IF;
		
		IF s = 1 and l>1 THEN
			for i in 2..l loop
				c:= substr(m,i,1);
				for cur1 in (select * from num1) LOOP
					B:= cur1.tokenname;
					IF c = B THEN
						s:=1;
						itr := itr+1;
						exit;
					ELSIF c = '.' THEN
						s:=2;
						itr := itr+1;
						exit;
					ELSE
						s:=0;	
					END IF;
				END LOOP;
				
				IF s = 0 or s = 2 THEN
					exit;
				END IF;
				
			end loop;
		END IF;
		itr := itr+1;
		IF s = 2 and l>1 THEN
			for i in itr..l loop
				c:= substr(m,i,1);
				for cur1 in (select * from num1) LOOP
					B:= cur1.tokenname;
					IF c = B THEN
						s:=1;
						exit;
					ELSE
						s:=0;						
					END IF;
				END LOOP;
				
				IF s = 0 THEN
					exit;
				END IF;
			end loop;
		END IF;
			
	END IF;
	
	n:= s;
	
return n;
END search2;


END mypack2;
/

