SET SERVEROUTPUT ON;


CREATE OR REPLACE TRIGGER Tr1 
BEFORE INSERT 
ON user1
DECLARE
BEGIN
	DBMS_OUTPUT.PUT_LINE('--------Lexeme Saved In Table.---------');
END;
/


CREATE OR REPLACE PACKAGE mypack3 AS
	
	PROCEDURE P1(B1 IN token1.tokenname%TYPE , D1 IN token1.tokenname%TYPE);
END mypack3;
/

CREATE OR REPLACE PACKAGE BODY mypack3 AS
	
	PROCEDURE P1(B1 IN token1.tokenname%TYPE , D1 IN token1.tokenname%TYPE)
	IS
	
	c NUMBER;
	
	BEGIN
	
	SELECT COUNT(*) into c FROM user1;
	--DBMS_OUTPUT.PUT_LINE(c);
	insert into user1 values(c+1,D1,B1);
	
	END P1;
	
END mypack3;
/




