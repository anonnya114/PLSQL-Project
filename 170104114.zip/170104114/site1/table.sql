clear screen;

drop table token2;

create table token2(id number, tokenname varchar2(20), tokentype varchar2(20));

insert into token2 values(33,'==','op');
insert into token2 values(34,'++','op');
insert into token2 values(35,'--','op');
insert into token2 values(36,'>=','op');
insert into token2 values(37,'<=','op');
insert into token2 values(38,'+=','op');
insert into token2 values(39,'-=','op');
insert into token2 values(40,'=+','op');
insert into token2 values(41,'=-','op');
insert into token2 values(42,'+','op');
insert into token2 values(43,'-','op');
insert into token2 values(44,'/','op');
insert into token2 values(45,'*','op');
insert into token2 values(47,'%','op');
insert into token2 values(46,'&&','op');
insert into token2 values(48,'||','op');
insert into token2 values(49,'(','br');
insert into token2 values(50,')','br');
insert into token2 values(51,'{','br');
insert into token2 values(52,'}','br');
insert into token2 values(53,'[','br');
insert into token2 values(54,']','br');
insert into token2 values(55,';','sep');
insert into token2 values(56,',','sep');


select * from token2;


drop table alphabet2;

create table alphabet2(id number, tokenname varchar2(20));

insert into alphabet2 values(27,'a');
insert into alphabet2 values(28,'b');
insert into alphabet2 values(29,'c');
insert into alphabet2 values(30,'d');
insert into alphabet2 values(31,'e');
insert into alphabet2 values(32,'f');
insert into alphabet2 values(33,'g');
insert into alphabet2 values(34,'h');
insert into alphabet2 values(35,'i');
insert into alphabet2 values(36,'j');
insert into alphabet2 values(37,'k');
insert into alphabet2 values(38,'l');
insert into alphabet2 values(39,'m');
insert into alphabet2 values(40,'n');
insert into alphabet2 values(41,'o');
insert into alphabet2 values(42,'p');
insert into alphabet2 values(43,'q');
insert into alphabet2 values(44,'r');
insert into alphabet2 values(45,'s');
insert into alphabet2 values(46,'t');
insert into alphabet2 values(47,'u');
insert into alphabet2 values(48,'v');
insert into alphabet2 values(49,'w');
insert into alphabet2 values(50,'x');
insert into alphabet2 values(51,'y');
insert into alphabet2 values(52,'z');
insert into alphabet2 values(53,'_');

select * from alphabet2;









