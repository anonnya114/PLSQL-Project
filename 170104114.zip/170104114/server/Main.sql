clear screen;
SET SERVEROUTPUT ON;
SET VERIFY OFF;


Accept x char prompt "Enter a lexeme :"

DECLARE
	A token1.id%TYPE;
	B token1.tokenname%TYPE;
	D token1.tokenname%TYPE;
	C token1.tokentype%TYPE;
	t token1.tokentype%TYPE;
	k number;
	found1 number :=0;
	Unkn_lex EXCEPTION;
	
	

BEGIN
	D:='&x';
	
	for cur1 in (select * from token1 union select * from token2@site1) LOOP
		B:= cur1.tokenname;
		C:= cur1.tokentype;
		IF B = D THEN
			found1:=1;
			IF C = 'kw' THEN
				DBMS_OUTPUT.PUT_LINE('The Token for the lexeme : Keyword');
				t:='Keyword';
			ELSIF C = 'br' THEN
				DBMS_OUTPUT.PUT_LINE('The Token for the lexeme : Bracket');
				t:='Bracket';
			ELSIF C = 'op' THEN
				DBMS_OUTPUT.PUT_LINE('The Token for the lexeme : Operator');
				t:='Operator';
			ELSIF C = 'sep' THEN
				DBMS_OUTPUT.PUT_LINE('The Token for the lexeme : Separator');
				t:='Separator';
			END IF;
		END IF;	
	END LOOP;	
	
	
	IF found1 = 0 THEN
		k:= mypack.search1(D);
		IF k = 1 THEN
			found1:=1;
			DBMS_OUTPUT.PUT_LINE('The Token for the lexeme : Function');
			t:='Function';
		ELSIF k = 2 THEN
			found1:=1;
			DBMS_OUTPUT.PUT_LINE('The Token for the lexeme : Identifier');
			t:='Identifier';
		END IF;
	END IF;

	
	IF found1 = 0 THEN
		k:= mypack2.search2(D);
		IF k = 1 THEN
			found1:=1;
			DBMS_OUTPUT.PUT_LINE('The Token for the lexeme : Numeric Constant');
			t:='Numeric Constant';
		ELSE
			RAISE Unkn_lex;
		END IF;
	END IF;
	
	--DBMS_OUTPUT.PUT_LINE(t);
	IF found1 = 1 THEN
		mypack3.P1(t,D);
	END IF;
	
	EXCEPTION
		WHEN Unkn_lex THEN
		DBMS_OUTPUT.PUT_LINE('--Invalid Lexeme Entered!!--');

	
END;
/


create or replace view myview(Serial_No, User_Input, Output_Token) as
select S.id, S.lexeme, S.tokenname
from user1 S;

select * from myview;

commit;
