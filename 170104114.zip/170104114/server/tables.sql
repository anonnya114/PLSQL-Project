clear screen;
drop table token1;
	
create table token1(id number, tokenname varchar2(20), tokentype varchar2(20));

insert into token1 values(1,'auto','kw');
insert into token1 values(2,'double','kw');
insert into token1 values(3,'int','kw');
insert into token1 values(4,'struct','kw');
insert into token1 values(5,'break','kw');
insert into token1 values(6,'else','kw');
insert into token1 values(7,'long','kw');
insert into token1 values(8,'switch','kw');
insert into token1 values(9,'case','kw');
insert into token1 values(10,'enum','kw');
insert into token1 values(11,'register','kw');
insert into token1 values(12,'typedef','kw');
insert into token1 values(13,'char','kw');
insert into token1 values(14,'extern','kw');
insert into token1 values(15,'return','kw');
insert into token1 values(16,'union','kw');
insert into token1 values(17,'continue','kw');
insert into token1 values(18,'for','kw');
insert into token1 values(19,'signed','kw');
insert into token1 values(20,'void','kw');
insert into token1 values(21,'do','kw');
insert into token1 values(22,'if','kw');
insert into token1 values(23,'static','kw');
insert into token1 values(24,'while','kw');
insert into token1 values(25,'default','kw');
insert into token1 values(26,'goto','kw');
insert into token1 values(27,'sizeof','kw');
insert into token1 values(28,'volatile','kw');
insert into token1 values(29,'const','kw');
insert into token1 values(30,'float','kw');
insert into token1 values(31,'short','kw');
insert into token1 values(32,'unsigned','kw');



drop table alphabet1;

create table alphabet1(id number, tokenname varchar2(20));


insert into alphabet1 values(1,'A');
insert into alphabet1 values(2,'B');
insert into alphabet1 values(3,'C');
insert into alphabet1 values(4,'D');
insert into alphabet1 values(5,'E');
insert into alphabet1 values(6,'F');
insert into alphabet1 values(7,'G');
insert into alphabet1 values(8,'H');
insert into alphabet1 values(9,'I');
insert into alphabet1 values(10,'J');
insert into alphabet1 values(11,'K');
insert into alphabet1 values(12,'L');
insert into alphabet1 values(13,'M');
insert into alphabet1 values(14,'N');
insert into alphabet1 values(15,'O');
insert into alphabet1 values(16,'P');
insert into alphabet1 values(17,'Q');
insert into alphabet1 values(18,'R');
insert into alphabet1 values(19,'S');
insert into alphabet1 values(20,'T');
insert into alphabet1 values(21,'U');
insert into alphabet1 values(22,'V');
insert into alphabet1 values(23,'W');
insert into alphabet1 values(24,'X');
insert into alphabet1 values(25,'Y');
insert into alphabet1 values(26,'Z');

drop table alphabet2;

create table alphabet2(id number, tokenname varchar2(20));

insert into alphabet2 values(27,'a');
insert into alphabet2 values(28,'b');
insert into alphabet2 values(29,'c');
insert into alphabet2 values(30,'d');
insert into alphabet2 values(31,'e');
insert into alphabet2 values(32,'f');
insert into alphabet2 values(33,'g');
insert into alphabet2 values(34,'h');
insert into alphabet2 values(35,'i');
insert into alphabet2 values(36,'j');
insert into alphabet2 values(37,'k');
insert into alphabet2 values(38,'l');
insert into alphabet2 values(39,'m');
insert into alphabet2 values(40,'n');
insert into alphabet2 values(41,'o');
insert into alphabet2 values(42,'p');
insert into alphabet2 values(43,'q');
insert into alphabet2 values(44,'r');
insert into alphabet2 values(45,'s');
insert into alphabet2 values(46,'t');
insert into alphabet2 values(47,'u');
insert into alphabet2 values(48,'v');
insert into alphabet2 values(49,'w');
insert into alphabet2 values(50,'x');
insert into alphabet2 values(51,'y');
insert into alphabet2 values(52,'z');
insert into alphabet2 values(53,'_');


drop table num1;

create table num1(id number, tokenname varchar2(20));

insert into num1 values(61,'0');
insert into num1 values(62,'1');
insert into num1 values(63,'2');
insert into num1 values(64,'3');
insert into num1 values(65,'4');
insert into num1 values(66,'5');
insert into num1 values(67,'6');
insert into num1 values(68,'7');
insert into num1 values(69,'8');
insert into num1 values(70,'9');

drop table user1;

create table user1(id number, lexeme varchar2(20), tokenname varchar2(20));


--select * from num1;
--select * from alphabet1 union (select * from alphabet2 union select * from num1);

--( select * from alphabet1 union select * from alphabet2@site1);
--( select * from token1 union  select * from token2@site1);




@"E:\Download\Aust\Aust 4-1\LAB\CSE4126 -Distributed Database\Project\package_identifier.sql"
@"E:\Download\Aust\Aust 4-1\LAB\CSE4126 -Distributed Database\Project\package_numConst.sql"
@"E:\Download\Aust\Aust 4-1\LAB\CSE4126 -Distributed Database\Project\package_insert.sql"


















