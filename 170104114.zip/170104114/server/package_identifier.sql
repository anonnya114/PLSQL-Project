clear screen;
SET SERVEROUTPUT ON;
SET VERIFY OFF;

CREATE OR REPLACE PACKAGE mypack AS

	FUNCTION search1(m IN token1.tokenname%TYPE)
	RETURN NUMBER;
END mypack;
/

CREATE OR REPLACE PACKAGE BODY mypack AS

function search1(m IN token1.tokenname%TYPE)
return number
is

l NUMBER;
c token1.tokenname%TYPE;
B alphabet1.tokenname%TYPE;
n NUMBER;



BEGIN
	l:= length(m);
	
	IF (m like '%[(][)]') then
	
		IF (m like 'A%' OR m like 'B%' OR m like 'C%' OR m like 'D%' OR m like 'E%'
			OR m like 'F%' OR m like 'G%' OR m like 'H%' OR m like 'I%' OR m like 'J%' 
			OR m like 'K%' OR m like 'M%' OR m like 'N%' OR m like 'O%' OR m like 'P%' 
			OR m like 'Q%' OR m like 'R%' OR m like 'S%' OR m like 'T%' OR m like 'U%'
			OR m like 'V%' OR m like 'W%' OR m like 'X%' OR m like 'Y%' OR m like 'Z%'
			OR m like 'a%' OR m like 'b%' OR m like 'c%' OR m like 'd%' OR m like 'e%' 
			OR m like 'f%' OR m like 'g%' OR m like 'h%' OR m like 'i%' OR m like 'j%' 
			OR m like 'k%' OR m like 'm%' OR m like 'n%' OR m like 'o%' OR m like 'p%'
			OR m like 'q%' OR m like 'r%' OR m like 's%' OR m like 't%' OR m like 'u%' 
			OR m like 'v%' OR m like 'w%' OR m like 'x%' OR m like 'y%' OR m like 'z%' OR m like '[_]%')THEN
			
			for i in 2..l loop
				c:= substr(m,i,1);
				for cur1 in (select * from alphabet1 union (select * from alphabet2 union select * from num1)) LOOP
					B:= cur1.tokenname;
					
					IF c = B THEN
						n:=1;
						exit;
					ELSE
						n:=0;
					END IF;
				END LOOP;
				IF n = 0 THEN
					exit;
				END IF;
			end loop;
		END IF;
		
	ELSE
	
		IF (m like 'A%' OR m like 'B%' OR m like 'C%' OR m like 'D%' OR m like 'E%'
			OR m like 'F%' OR m like 'G%' OR m like 'H%' OR m like 'I%' OR m like 'J%' 
			OR m like 'K%' OR m like 'L%' OR m like 'M%' OR m like 'N%' OR m like 'O%' OR m like 'P%' 
			OR m like 'Q%' OR m like 'R%' OR m like 'S%' OR m like 'T%' OR m like 'U%'
			OR m like 'V%' OR m like 'W%' OR m like 'X%' OR m like 'Y%' OR m like 'Z%'
			OR m like 'a%' OR m like 'b%' OR m like 'c%' OR m like 'd%' OR m like 'e%' 
			OR m like 'f%' OR m like 'g%' OR m like 'h%' OR m like 'i%' OR m like 'j%' 
			OR m like 'k%' OR m like 'l%' OR m like 'm%' OR m like 'n%' OR m like 'o%' OR m like 'p%'
			OR m like 'q%' OR m like 'r%' OR m like 's%' OR m like 't%' OR m like 'u%' 
			OR m like 'v%' OR m like 'w%' OR m like 'x%' OR m like 'y%' OR m like 'z%' ) THEN
			
			IF l = 1 THEN
				n:=2;
			END IF;
			
			for i in 2..l loop
				c:= substr(m,i,1);
				for cur1 in (select * from alphabet1 union (select * from alphabet2 union select * from num1)) LOOP
					B:= cur1.tokenname;
					
					IF c = B THEN
						n:=2;
						exit;
					ELSE
						n:=0;
					END IF;
				END LOOP;
				IF n = 0 THEN
					exit;
				END IF;
				
			end loop;
		END IF;
	
	END IF;

return n;
END search1;


END mypack;
/

